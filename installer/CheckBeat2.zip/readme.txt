Program: CheckBeat
Version: 2
Operating System:  Windows
Release Date: 09/03/2006
Author:  Xangis
License:  Freeware
Download Location:  http://www.zetacentauri.com
Installation:  Unzip anywhere convenient.

Use:  Run the program.  It comes with a default set of sounds, but
      you can load any .wav sample by clicking the "browse" button.

      To start the drum machine, you click the start button.  Before
      starting, you will want to set the beats/minute and beats per
      pattern numbers.  Beats per pattern determines how many of the
      sixteen checkboxes will be read for each sound during playback.
      You can use this to set odd time signatures like 5/4.  Most
      of the time you will probably want to leave it at 16.

      You can select any of four different time divisions: quarter,
      eighth, sixteenth, and thirty-second notes.  Each check box
      represents a single division (note).

      To have a sample trigger at a specific beat, just put a check
      in the proper box.  Boxes are read in realtime, so you can
      check and uncheck boxes while the beat is playing.

      Tempo and beats per pattern are not read in realtime, so you
      will have to stop and start again if you want to change those
      values.

      You can load a different sample while sound is playing and the
      pattern will continue, using the new sound instead of the old.